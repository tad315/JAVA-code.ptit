package J04006;
import java.util.Scanner;

public class J04006 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Sv sv = new Sv();
        sv.nhap(sc);
        System.out.println(sv);
    }
}
