package baiJ;
import java.io.*;
import java.util.*;

public class baiJ {
    public static void main(String[] args) throws Exception{
        Scanner sc = new Scanner(new File("MONHOC.in"));
        ArrayList<MonHoc> list = new ArrayList<>();
        HashSet<String> seen = new HashSet<>();
        while(sc.hasNextLine()) {
            String ma = sc.nextLine().trim();
            if(!sc.hasNextLine()) break;
            String ten = sc.nextLine().trim();
            if(!sc.hasNextLine()) break;
            String hinhThuc = sc.nextLine().trim();
            if(!seen.contains(ma)) {
                seen.add(ma);
                list.add(new MonHoc(ma, ten, hinhThuc));
            }
            Collections.sort(list);
            for(MonHoc m: list){
                System.out.println(m);
            }
        }
    }
}
