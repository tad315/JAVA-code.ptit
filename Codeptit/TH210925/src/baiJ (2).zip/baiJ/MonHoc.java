package baiJ;

public class MonHoc implements Comparable<MonHoc> {
    private String ma, ten, hinhThuc;

    public MonHoc(String ma, String ten, String hinhThuc) {
        this.ma = ma.trim();
        this.ten = ten.trim();
        this.hinhThuc = hinhThuc.trim();
    }
    public String getMa() {
        return ma;
    }

    public int compareTo(MonHoc o) {
        return this.ma.compareTo(o.ma);
    }
    public String toString() {
        return ma + " "  + ten + " " + hinhThuc;
    }
}
