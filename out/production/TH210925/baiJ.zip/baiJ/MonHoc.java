package baiJ;

public class MonHoc implements Comparable<MonHoc> {
    private String ma, ten, hinhThuc;

    public MonHoc(String ma, String ten, String hinhThuc) {
        this.ma = ma;
        this.ten = ten;
        this.hinhThuc = hinhThuc;
    }
    public String getMa() {
        return ma;
    }

    public int compareTo(MonHoc o) {
        return this.ma.compareTo(o.ma);
    }
    public String toString() {
        return ma + " "  + ten + " " + hinhThuc;
    }
}
