package baiG;

public class SanPham {
    String ma, ten;
    int gia, bh;
    public SanPham(String ma, String ten, int gia, int bh) {
        this.ma = ma;
        this.ten = ten;
        this.gia = gia;
        this.bh = bh;
    }
}
