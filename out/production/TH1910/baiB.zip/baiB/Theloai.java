package baiB;

public class Theloai {
    private final String id, name;
    public Theloai(String id, String name) {
        this.id = id;
        this.name = name;
    }
    public String getId(){ return id; }
    public String getName() { return name; }
}
