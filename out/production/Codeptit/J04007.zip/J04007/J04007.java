package J04007;
import java.util.Scanner;

public class J04007 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        NV nv = new NV();
        nv.nhap(sc);
        System.out.println(nv);
    }
}
