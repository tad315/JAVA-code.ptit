package J02009;

public class Customer {
    int arrival, durantion;
    public Customer (int a, int d) {
        arrival = a;
        durantion = d;
    }
}
